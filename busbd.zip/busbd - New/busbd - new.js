import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Counter } from 'k6/metrics';
import { SharedArray } from 'k6/data';
import exec from 'k6/execution';

/*
  Shyamoli staging — admin counter booking

  Homepage → Login → Search destination & date → Seat view → Seat booked/issued

  Set VUS and DURATION once (below or with -e), then:

    k6 run busbd.js
    k6 run -e VUS=300000 -e DURATION=10m busbd.js

  VUS is the total hits you want. This PC cannot open 300000 VUs at once
  (8 GB RAM), so the script uses a small batch and keeps going until those
  hits finish, or DURATION ends — whichever comes first.
*/

const BASE_URL = __ENV.BASE_URL || 'https://staging.shyamoliparibahan-bd.com';
const PASSWORD = __ENV.PASSWORD || '123456';

// ============================================================
const VUS = Number(__ENV.VUS || 300000);
const DURATION = __ENV.DURATION || '10m';
// ============================================================

const RAM_SAFE_VUS = 100;
const CONCURRENT_VUS = Math.min(Math.max(1, VUS), RAM_SAFE_VUS);
const TARGET_HITS = Math.max(VUS, CONCURRENT_VUS);
const RAMP_SECONDS = Number(__ENV.RAMP_SECONDS || 60);

const DATES = String(
  __ENV.DEPART_DATES ||
    '21/10/2026,22/10/2026,23/10/2026,24/10/2026,25/10/2026,26/10/2026,27/10/2026,28/10/2026,29/10/2026,30/10/2026,31/10/2026,01/11/2026,02/11/2026,03/11/2026'
)
  .split(',')
  .map(function (d) {
    return d.trim();
  })
  .filter(Boolean);

const DISTRICTS = {
  Dhaka: '14',
  Bandarban: '2',
  Chittagong: '10',
  Sylhet: '63',
  "Cox's Bazar": '13',
  Rangamati: '56',
};

const ROUTES = [
  ['Dhaka', 'Bandarban'],
  ['Dhaka', 'Chittagong'],
  ['Dhaka', 'Sylhet'],
  ['Dhaka', "Cox's Bazar"],
  ['Dhaka', 'Rangamati'],
  ['Bandarban', 'Dhaka'],
  ['Chittagong', 'Dhaka'],
  ['Sylhet', 'Dhaka'],
  ["Cox's Bazar", 'Dhaka'],
  ['Rangamati', 'Dhaka'],
];

const users = new SharedArray('admin-users', function () {
  const files = ['./admin-users.txt', './message.txt'];
  let raw = '';
  for (let f = 0; f < files.length && !raw; f++) {
    try {
      raw = open(files[f]);
    } catch (e) {
      raw = '';
    }
  }
  const rows = [];
  const lines = String(raw).split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line.charAt(0) === '#') continue;
    if (line.charAt(0) === '"' && line.charAt(line.length - 1) === '"') {
      line = line.slice(1, -1).trim();
    }
    const comma = line.indexOf(',');
    const username = comma === -1 ? line : line.slice(0, comma).trim();
    const password = comma === -1 ? PASSWORD : line.slice(comma + 1).trim() || PASSWORD;
    const key = username.toLowerCase();
    if (!username || key === 'username' || key === 'user_name') continue;
    rows.push({ username: username, password: password });
  }
  if (!rows.length) rows.push({ username: 'busbd', password: PASSWORD });
  return rows;
});

export const options = {
  discardResponseBodies: true,
  noConnectionReuse: false,
  setupTimeout: '5m',
  dns: { ttl: '5m', select: 'first', policy: 'preferIPv4' },
  cloud: {
    name: 'Shyamoli 200k hits low VU',
  },
  scenarios: {
    booking: {
      executor: 'shared-iterations',
      vus: CONCURRENT_VUS,
      iterations: TARGET_HITS,
      maxDuration: DURATION,
      gracefulStop: '30s',
    },
  },
  thresholds: {
    login_success: ['count>0'],
    book_success: ['count>0'],
  },
};

const loginSuccess = new Counter('login_success');
const loginFail = new Counter('login_fail');
const searchSuccess = new Counter('search_success');
const searchFail = new Counter('search_fail');
const seatViewSuccess = new Counter('seatview_success');
const seatViewFail = new Counter('seatview_fail');
const bookSuccess = new Counter('book_success');
const bookFail = new Counter('book_fail');

http.setResponseCallback(http.expectedStatuses(200, 301, 302, 400, 409, 500, 502, 503, 504));

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

function formBody(obj) {
  const parts = [];
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const value = obj[keys[i]] == null ? '' : obj[keys[i]];
    parts.push(encodeURIComponent(keys[i]) + '=' + encodeURIComponent(value));
  }
  return parts.join('&');
}

function params(session, opts) {
  const headers = opts.ajax
    ? {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        Accept: 'application/json, text/javascript, */*; q=0.01',
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': UA,
        Referer: opts.referer || BASE_URL + '/en_US/admin/dashboard',
      }
    : {
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'User-Agent': UA,
        Referer: opts.referer || BASE_URL + '/',
      };
  return {
    headers: headers,
    jar: session.jar,
    tags: { name: opts.name },
    timeout: opts.timeout || '15s',
    redirects: 0,
    responseType: opts.keepBody === false ? 'none' : 'text',
  };
}

function header(res, name) {
  if (!res || !res.headers) return '';
  const want = name.toLowerCase();
  const keys = Object.keys(res.headers);
  for (let i = 0; i < keys.length; i++) {
    if (String(keys[i]).toLowerCase() === want) return String(res.headers[keys[i]] || '');
  }
  return '';
}

function isRecaptcha(res) {
  if (header(res, 'Location').toLowerCase().indexOf('recaptcha') !== -1) return true;
  if (!res || !res.body) return false;
  const body = String(res.body);
  return body.length < 500 && body.indexOf('window.location.href') !== -1;
}

function passRecaptcha(session) {
  http.get(BASE_URL + '/recaptcha/', params(session, { name: '00_Recaptcha', keepBody: false }));
  sleep(3.2);
}

function asList(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.filter(function (row) { return !!row; });
  const out = [];
  const keys = Object.keys(value);
  for (let i = 0; i < keys.length; i++) {
    if (value[keys[i]]) out.push(value[keys[i]]);
  }
  return out;
}

function safeJson(res) {
  if (!res || !res.body) return null;
  try {
    return res.json();
  } catch (e) {
    return null;
  }
}

function extractLoginCsrf(html) {
  const match = String(html).match(/name="csrf"\s+value="([^"]+)"/i);
  return match ? match[1] : '';
}

function extractDashboardCsrf(html) {
  const match = String(html).match(/csrfToken\s*=\s*"([a-f0-9]+)"/i);
  return match ? match[1] : '';
}

function extractSeatbookingToken(html) {
  const match = String(html).match(/name="seatbooking_token"\s+value="([^"]+)"/i);
  return match ? match[1] : '';
}

function isOpenCoach(coach) {
  if (!coach || !coach.coachconfig_sku) return false;
  const status = coach.status == null ? '' : String(coach.status).toLowerCase();
  const configStatus = coach.coachconfig_status == null ? '' : String(coach.coachconfig_status).toLowerCase();
  if (!status && configStatus === 'open') return true;
  return status === 'open';
}

function coachesFromSearch(data) {
  if (!data) return [];
  let rows = data.contents != null ? asList(data.contents) : [];
  if (!rows.length) rows = asList(data);
  return rows.filter(isOpenCoach);
}

function fareFor(allFares, fromId, toId, seatTypeId) {
  const rows = asList(allFares);
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    if (
      String(row.from_district_id) === String(fromId) &&
      String(row.to_district_id) === String(toId) &&
      String(row.seat_type_id) === String(seatTypeId)
    ) {
      return String(row.fare);
    }
  }
  return '';
}

function pickPoint(points, districtKey, districtId) {
  const rows = asList(points);
  rows.sort(function (a, b) {
    return (Number(a.config_details_sort) || 0) - (Number(b.config_details_sort) || 0);
  });
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][districtKey]) === String(districtId)) return rows[i];
  }
  return rows.length ? rows[0] : null;
}

function pointTitle(name, time) {
  return time ? name + ' ( ' + time + ' ) ' : name;
}

function takenIds(map) {
  const ids = {};
  if (!map || Array.isArray(map)) return ids;
  const keys = Object.keys(map);
  for (let i = 0; i < keys.length; i++) ids[String(keys[i])] = true;
  return ids;
}

function availableSeats(seatData, fromId, toId) {
  const details = asList(seatData.seatstructure_details);
  const sold = takenIds(seatData.coach_seatstatus);
  const held = takenIds(seatData.temporary_booked);
  const vip = asList(seatData.vip_seatquota);
  const blocked = {};
  for (let i = 0; i < vip.length; i++) {
    if (vip[i]) blocked[String(vip[i])] = true;
  }
  const seats = [];
  const later = [];
  for (let i = 0; i < details.length; i++) {
    const seat = details[i];
    if (!seat || !seat.seat_structure_details_id || !seat.seat_no) continue;
    const id = String(seat.seat_structure_details_id);
    if (sold[id] || held[id] || blocked[id]) continue;
    const fare = fareFor(seatData.coach_allfares, fromId, toId, seat.seat_type_id);
    if (!fare || Number(fare) <= 0) continue;
    const row = {
      id: id,
      seatNo: String(seat.seat_no),
      seatTypeId: String(seat.seat_type_id),
      fare: fare,
    };
    if (row.seatNo.indexOf('U-') === 0 || row.seatNo.indexOf('L-') === 0) later.push(row);
    else seats.push(row);
  }
  return seats.concat(later);
}

function routeFor(id, iter) {
  const pair = ROUTES[(id - 1 + iter) % ROUTES.length];
  return {
    fromName: pair[0],
    toName: pair[1],
    fromId: DISTRICTS[pair[0]],
    toId: DISTRICTS[pair[1]],
  };
}

function dateFor(id) {
  return DATES[(id - 1) % DATES.length];
}

function datesForUser(id) {
  const start = (id - 1) % DATES.length;
  const out = [];
  for (let i = 0; i < DATES.length; i++) out.push(DATES[(start + i) % DATES.length]);
  return out;
}

function visitHome(s) {
  http.get(BASE_URL + '/', params(s, { name: '01_Home', keepBody: false, timeout: '12s' }));
}

function login(s) {
  let page = http.get(BASE_URL + '/en_US/login', params(s, { name: '02_LoginPage', timeout: '20s' }));
  if (isRecaptcha(page) || !extractLoginCsrf(page && page.body)) {
    passRecaptcha(s);
    page = http.get(BASE_URL + '/en_US/login', params(s, { name: '02_LoginPage', timeout: '20s' }));
  }

  const loginCsrf = extractLoginCsrf(page && page.body);
  if (!loginCsrf) {
    loginFail.add(1);
    return false;
  }

  let res = http.post(
    BASE_URL + '/en_US/login',
    formBody({
      form_key: '',
      csrf: loginCsrf,
      username: s.user.username,
      password: s.user.password,
      'g-recaptcha-response': '',
      google_captcha_site_key: '6Ld8ISssAAAAANLAtGnPM9zE8WuJHTiyYdJaANAi',
      macAddress: '',
      device_token: 'k6-' + s.user.username + '-' + s.id,
      LoginWidgetSubmitButton: 'Login',
    }),
    params(s, { name: '03_Login', referer: BASE_URL + '/en_US/login', timeout: '20s' })
  );

  if (extractDashboardCsrf(res && res.body)) {
    s.csrf = extractDashboardCsrf(res.body);
    s.seatToken = extractSeatbookingToken(res.body);
  } else {
    if (isRecaptcha(res)) passRecaptcha(s);
    res = http.get(
      BASE_URL + '/en_US/admin/dashboard',
      params(s, { name: '03_Dashboard', referer: BASE_URL + '/en_US/login', timeout: '25s' })
    );
    if (isRecaptcha(res) || !extractDashboardCsrf(res && res.body)) {
      passRecaptcha(s);
      res = http.get(
        BASE_URL + '/en_US/admin/dashboard',
        params(s, { name: '03_Dashboard', referer: BASE_URL + '/en_US/login', timeout: '25s' })
      );
    }
    s.csrf = extractDashboardCsrf(res && res.body);
    s.seatToken = extractSeatbookingToken(res && res.body);
  }

  const ok = !!s.csrf;
  check(res, { 'login reaches dashboard': function () { return ok; } });
  if (ok) loginSuccess.add(1);
  else loginFail.add(1);
  return ok;
}

function search(s) {
  const dates = datesForUser(s.id);
  const tries = dates.slice(0, 3);
  let lastRes = null;

  for (let d = 0; d < tries.length; d++) {
    s.date = tries[d];
    lastRes = http.post(
      BASE_URL + '/en_US/admin/counter/for/seatbookingsearch',
      formBody({
        csrfToken: s.csrf,
        searchmenu_leavingform: s.route.fromId,
        searchmenu_goingto: s.route.toId,
        searchmenu_coachno: '',
        searchmenu_departingon: s.date,
        searchmenu_departingtime: '',
        searchmenu_search_type: '0',
        searchmenu_submitbutton: 'Search',
        seatbooking_token: s.seatToken || '',
      }),
      params(s, { name: '04_Search', ajax: true })
    );

    const coaches = coachesFromSearch(safeJson(lastRes));
    const ok = !!(lastRes && lastRes.status === 200 && coaches.length);
    if (!ok) continue;

    check(lastRes, { 'search returns coaches': function () { return true; } });
    const start = (s.id + s.iter + d) % coaches.length;
    s.coaches = coaches.slice(start).concat(coaches.slice(0, start)).slice(0, 3);
    searchSuccess.add(1);
    return true;
  }

  check(lastRes, { 'search returns coaches': function () { return false; } });
  searchFail.add(1);
  return false;
}

function viewSeat(s) {
  for (let i = 0; i < s.coaches.length; i++) {
    const coach = s.coaches[i];
    const res = http.post(
      BASE_URL + '/en_US/ajax/counterseatbooking/coach/seatlist',
      formBody({
        schedule: coach.departure_time || '',
        cc_sku: coach.coachconfig_sku,
        journey_date: s.date,
        to_district: s.route.toId,
        from_district: s.route.fromId,
        selectedBordingPoint: '',
        selectedDroppingPoint: '',
        csrfToken: s.csrf,
      }),
      params(s, { name: '05_ViewSeat', ajax: true })
    );

    const data = safeJson(res);
    const ok = !!(res && res.status === 200 && data && data.message === 'success');
    check(res, { 'view seat': function () { return ok; } });
    if (!ok) {
      seatViewFail.add(1);
      continue;
    }
    seatViewSuccess.add(1);

    const boarding = pickPoint(data.bording_points, 'fromcounter_districtid', s.route.fromId);
    const dropping = pickPoint(data.dropping_points, 'tocounter_districtid', s.route.toId);
    const seats = availableSeats(data, s.route.fromId, s.route.toId);
    if (!boarding || !dropping || !boarding.reporting_branch_id || !dropping.reporting_branch_id || !seats.length) {
      continue;
    }

    const seatStart = (s.id + i) % seats.length;
    s.coach = {
      coachconfig_sku: coach.coachconfig_sku,
      departure_time: coach.departure_time,
      coach_no: coach.coach_no,
    };
    s.boarding = {
      id: String(boarding.reporting_branch_id),
      title: pointTitle(boarding.counter_name, boarding.reporting_time),
      districtId: String(boarding.fromcounter_districtid || s.route.fromId),
    };
    s.dropping = {
      id: String(dropping.reporting_branch_id),
      title: pointTitle(dropping.counter_name, dropping.droping_time),
      districtId: String(dropping.tocounter_districtid || s.route.toId),
    };
    s.seats = seats.slice(seatStart).concat(seats.slice(0, seatStart)).slice(0, 2);
    return true;
  }
  return false;
}

function issueSeat(s) {
  for (let i = 0; i < s.seats.length; i++) {
    const seat = s.seats[i];
    const ticketRes = http.post(
      BASE_URL + '/en_US/ajax/issue/ticket/randomticketnumber',
      'random_number=1',
      params(s, { name: '06_TicketNo', ajax: true })
    );
    const ticket = ticketRes && ticketRes.status === 200 ? String(ticketRes.body || '').trim() : '';
    if (!ticket || ticket.charAt(0) === '<' || ticket.charAt(0) === '{') continue;

    const res = http.post(
      BASE_URL + '/en_US/ajax/counter/seatbooking/ticket/purchase',
      formBody({
        sashroyToken: '',
        sashroyTransactionID: '',
        sashroyTicketAttr: '',
        eMail: '',
        goods_weight: '',
        goods_discount: '',
        goods_fare: '0',
        couponTitle: '',
        couponCodeToken: '',
        iscounterquotaallowed: '',
        complementary_seats: '',
        currentallowedquota: '',
        quota_status: 'false',
        seat_count: '1',
        seats: seat.id,
        seats_title: seat.seatNo,
        seats_fare: seat.fare,
        discount_fare: '0',
        amount: seat.fare,
        bording_point: s.boarding.id,
        bording_point_title: s.boarding.title,
        droppingpoint: s.dropping.id,
        droppingpoint_title: s.dropping.title,
        name: 'Load ' + s.user.username + ' ' + s.id,
        buyer_address: '',
        buyer_passport: '',
        additional_passenger_name: '',
        additional_passenger_passport: '',
        gender: 'Male',
        age: '',
        reg: '',
        mobile_prefix: '+88',
        mobile: String(17000000000 + ((s.id - 1) * 50 + s.iter) % 100000000),
        bags_pics: '',
        bags_weight: '',
        counter_payment_method_id: 'cash',
        counter_payment_method_title: 'Cash',
        nationality_id: 'bangladesh',
        nationality_title: 'Bangladesh',
        buyer_visa_no: '',
        buyer_visa_exp_date: '',
        journey_date: s.date,
        journey_time: s.coach.departure_time || '',
        from_district: s.boarding.districtId || s.route.fromId,
        to_district: s.dropping.districtId || s.route.toId,
        tickets_flag: '',
        tickets_flag_id: '',
        tickets_no: ticket,
        booking_type: 'seat_issue',
        cc_sku: s.coach.coachconfig_sku,
        booking_expire_date: '',
        booking_expire_time: '',
        advancePaid: '0',
        applied_variable_discount_amount: '0',
        csrfToken: s.csrf,
      }),
      params(s, { name: '07_Confirm', ajax: true, timeout: '20s' })
    );

    const data = safeJson(res);
    if (data && data.csrfToken) s.csrf = data.csrfToken;
    const ok = !!(res && res.status === 200 && data && data.message === 'success');
    check(res, { 'seat booked or issued': function () { return ok; } });
    if (ok) {
      bookSuccess.add(1);
      return true;
    }
    const reason = String((data && (data.message_details || data.message)) || '');
    if (reason.toUpperCase().indexOf('INSUFFICIENT') !== -1 || reason.toUpperCase().indexOf('AMOUNT EMPTY') !== -1) {
      break;
    }
  }
  bookFail.add(1);
  return false;
}

export function setup() {
  console.log(
    'Target hits=' +
      TARGET_HITS +
      ' running with ' +
      CONCURRENT_VUS +
      ' VUs (8 GB RAM) ramp=' +
      RAMP_SECONDS +
      's duration=' +
      DURATION +
      ' dates=' +
      DATES.join(',') +
      ' url=' +
      BASE_URL
  );

  let res = null;
  for (let attempt = 1; attempt <= 5; attempt++) {
    res = http.get(BASE_URL + '/en_US/login', {
      timeout: '20s',
      headers: { 'User-Agent': UA, Accept: 'text/html' },
      tags: { name: '00_Reachability' },
      responseType: 'text',
      redirects: 0,
    });
    if (res && res.status === 200 && extractLoginCsrf(res.body)) break;
    if (isRecaptcha(res) || (res && (res.status === 301 || res.status === 302))) {
      http.get(BASE_URL + '/recaptcha/', {
        timeout: '15s',
        headers: { 'User-Agent': UA, Accept: 'text/html' },
        tags: { name: '00_Recaptcha' },
        responseType: 'none',
        redirects: 0,
      });
      sleep(3.2);
      continue;
    }
    if (res && res.status >= 500) break;
    if (attempt < 5) sleep(2 * attempt);
  }
  if (!res || res.status === 0) {
    throw new Error('Staging did not respond at ' + BASE_URL);
  }
  if (res.status >= 500) {
    throw new Error('Staging returned HTTP ' + res.status + ' for login');
  }
  if (res.status !== 200 || !extractLoginCsrf(res.body)) {
    throw new Error('Login page is still behind /recaptcha. Open the site in a browser once, then run k6 again.');
  }
}

export default function () {
  const id = exec.vu.idInTest;
  if (__ITER === 0) {
    sleep(((id - 1) % CONCURRENT_VUS) * (RAMP_SECONDS / CONCURRENT_VUS));
  }

  const s = {
    id: id,
    iter: __ITER,
    jar: new http.CookieJar(),
    user: users[(id - 1) % users.length],
    route: routeFor(id, __ITER),
    date: dateFor(id),
    csrf: '',
    seatToken: '',
  };

  group('Homepage', function () {
    visitHome(s);
  });

  let ok = false;
  group('Login', function () {
    ok = login(s);
  });
  if (!ok) return;

  group('Search Destination and Date', function () {
    ok = search(s);
  });
  if (!ok) return;

  group('Seat View', function () {
    ok = viewSeat(s);
  });
  if (!ok) {
    bookFail.add(1);
    return;
  }

  group('Seat Booked or Issued', function () {
    issueSeat(s);
  });
}

export function handleSummary(data) {
  const get = function (name) {
    return (data.metrics[name] && data.metrics[name].values && data.metrics[name].values.count) || 0;
  };

  const hitsDone = get('iterations');
  const httpReqs = get('http_reqs');
  const report =
    '\n============================================================\n' +
    'Shyamoli staging — admin counter booking\n' +
    'URL      : ' + BASE_URL + '\n' +
    'Dates    : ' + DATES.join(', ') + '\n' +
    'VUs (8GB)      : ' + CONCURRENT_VUS + '\n' +
    'Target hits    : ' + TARGET_HITS + '\n' +
    'Hits completed : ' + hitsDone + '\n' +
    'HTTP requests  : ' + httpReqs + '\n' +
    'Max duration   : ' + DURATION + '\n' +
    '============================================================\n' +
    'Homepage → Login → Search → Seat View → Seat Booked/Issued\n' +
    'Login    success : ' + get('login_success') + '\n' +
    'Login    failed  : ' + get('login_fail') + '\n' +
    'Search   success : ' + get('search_success') + '\n' +
    'Search   failed  : ' + get('search_fail') + '\n' +
    'ViewSeat success : ' + get('seatview_success') + '\n' +
    'ViewSeat failed  : ' + get('seatview_fail') + '\n' +
    'Booked   success : ' + get('book_success') + '\n' +
    'Booked   failed  : ' + get('book_fail') + '\n' +
    '============================================================\n';

  return {
    stdout: report,
    'busbd-result.json': JSON.stringify(
      {
        concurrent_vus: CONCURRENT_VUS,
        target_hits: TARGET_HITS,
        hits_completed: hitsDone,
        http_reqs: httpReqs,
        max_duration: DURATION,
        dates: DATES,
        login_success: get('login_success'),
        login_fail: get('login_fail'),
        search_success: get('search_success'),
        search_fail: get('search_fail'),
        seatview_success: get('seatview_success'),
        seatview_fail: get('seatview_fail'),
        book_success: get('book_success'),
        book_fail: get('book_fail'),
      },
      null,
      2
    ),
  };
}
